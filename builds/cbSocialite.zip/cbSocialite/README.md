# Socialite for ContentBox

A cool module to handle oauth2 authentication.

Currently support:

* Facebook
* Google
* Linkedin
* Github

Usage:

Go to module page in admin and add your credentials.
